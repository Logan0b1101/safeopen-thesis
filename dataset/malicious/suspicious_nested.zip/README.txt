This is a test archive. Contains nested payload.
