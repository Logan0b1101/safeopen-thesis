/* harmless js-like file */
app.alert('safeopen test');
